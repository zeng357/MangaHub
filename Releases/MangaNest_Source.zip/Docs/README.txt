# Docs — User Guides & Documents

This folder contains all user-facing documentation:

| File | Content |
|---|---|
| `Usage.md` | Main UI walkthrough + download flow + adding sites + FAQ |
| `How-to-Add-a-New-Site.md` | Add any manga site with a JSON adapter (no coding) |
| `How-to-Add-a-Custom-Crawler.md` | Add any manga site with a Python crawler source |
| `Chapter-List-Feature.md` | Description of the chapter-list (checkable) feature |
| `DISCLAIMER.txt` | Disclaimer (English & Chinese) |
