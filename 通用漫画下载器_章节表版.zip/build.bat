@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo  通用漫画下载器 - 一键打包脚本（生成 dist\通用漫画下载器.exe）
echo  包含章节表功能 + 新增“漫画客”站点
echo ============================================================
echo.

REM 1) 选择 Python：优先使用已装好 DrissionPage+PyInstaller 的 Python3.10
set "PY="
if exist "C:\Users\15916\AppData\Local\Programs\Python\Python310\python.exe" set "PY=C:\Users\15916\AppData\Local\Programs\Python\Python310\python.exe"
if "%PY%"=="" for /f "delims=" %%x in ('where python 2^>nul') do set "PY=%%x"
if "%PY%"=="" (
    echo [错误] 未找到 python，请先安装 Python 3.10 并加入 PATH。
    pause
    exit /b 1
)
for /f "delims=" %%v in ('"%PY%" --version 2^>^&1') do set PYVER=%%v
echo 使用 Python: %PYVER%  (%PY%)

REM 2) 安装依赖（如已安装会自动跳过）
echo.
echo [1/3] 安装 DrissionPage 与 PyInstaller ...
"%PY%" -m pip install --upgrade DrissionPage pyinstaller
if errorlevel 1 (
    echo [错误] 安装依赖失败，请检查网络后重试。
    pause
    exit /b 1
)

REM 3) 用 PyInstaller 打包（单文件、无控制台窗口、内嵌 DrissionPage）
echo.
echo [2/3] 开始打包（约需 1-3 分钟）...
"%PY%" -m PyInstaller --noconfirm --clean --onefile --windowed ^
    --name 通用漫画下载器 ^
    --collect-all DrissionPage ^
    --hidden-import DrissionPage ^
    gui.py
if errorlevel 1 (
    echo [错误] 打包失败，请查看上方日志。
    pause
    exit /b 1
)

REM 4) 把站点/配置/目录复制到 dist（exe 运行时从自身所在目录读取）
echo.
echo [3/3] 复制站点与配置到 dist\ ...
xcopy /E /I /Y "%~dp0sites_data" "dist\sites_data" >nul
if not exist "dist\cookies" mkdir "dist\cookies"
copy /Y "%~dp0config.json" "dist\config.json" >nul 2>nul
if not exist "%~dp0config.json" (
    REM 没有 config.json 也无妨，程序会按默认配置运行
    echo  （未发现 config.json，首次运行将按默认设置生成）
)

echo.
echo ============================================================
echo  打包完成！运行方式：
echo   双击  dist\通用漫画下载器.exe
echo  （dist\ 目录请整体保留，sites_data 与 config 需与 exe 同目录）
echo ============================================================
pause
endlocal
